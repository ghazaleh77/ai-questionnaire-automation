<?php
/**
 * Plugin Name: AI Questionnaire System
 * Plugin URI: https://yoursite.com
 * Description: سیستم پرسشنامه با تحلیل هوش مصنوعی و اتصال به n8n
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://yoursite.com
 * Text Domain: ai-questionnaire
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.2
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// جلوگیری از دسترسی مستقیم
if (!defined('ABSPATH')) {
    exit;
}

// تعریف ثابت‌ها
define('AIQ_VERSION', '1.0.0');
define('AIQ_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AIQ_PLUGIN_URL', plugin_dir_url(__FILE__));

class AI_Questionnaire_System {
    
    private $table_questions;
    private $table_answers;
    private $table_analysis;
    
    public function __construct() {
        global $wpdb;
        $this->table_questions = $wpdb->prefix . 'aiq_questions';
        $this->table_answers = $wpdb->prefix . 'aiq_answers';
        $this->table_analysis = $wpdb->prefix . 'aiq_analysis';
        
        // هوک‌های وردپرس
        register_activation_hook(__FILE__, array($this, 'activate'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('ai_questionnaire', array($this, 'questionnaire_shortcode'));
        
        // AJAX handlers
        add_action('wp_ajax_aiq_save_question', array($this, 'save_question'));
        add_action('wp_ajax_aiq_delete_question', array($this, 'delete_question'));
        add_action('wp_ajax_aiq_submit_answers', array($this, 'handle_submit_answers'));
        add_action('wp_ajax_aiq_get_user_analysis', array($this, 'get_user_analysis'));
        add_action('wp_ajax_aiq_update_settings', array($this, 'update_settings'));
    }
    
    // ایجاد جداول در زمان فعال‌سازی
    public function activate() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql_questions = "CREATE TABLE IF NOT EXISTS {$this->table_questions} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            question_text text NOT NULL,
            question_order int(11) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        $sql_answers = "CREATE TABLE IF NOT EXISTS {$this->table_answers} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            question_id mediumint(9) NOT NULL,
            answer_text text NOT NULL,
            submitted_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY question_id (question_id)
        ) $charset_collate;";
        
        $sql_analysis = "CREATE TABLE IF NOT EXISTS {$this->table_analysis} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            analysis_text longtext NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_questions);
        dbDelta($sql_answers);
        dbDelta($sql_analysis);
        
        // تنظیمات پیش‌فرض
        if (!get_option('aiq_n8n_webhook_url')) {
            add_option('aiq_n8n_webhook_url', '');
        }
    }
    
    // منوی ادمین
    public function add_admin_menu() {
        add_menu_page(
            'پرسشنامه AI',
            'پرسشنامه AI',
            'manage_options',
            'ai-questionnaire',
            array($this, 'admin_questions_page'),
            'dashicons-forms',
            30
        );
        
        add_submenu_page(
            'ai-questionnaire',
            'مدیریت سوالات',
            'سوالات',
            'manage_options',
            'ai-questionnaire',
            array($this, 'admin_questions_page')
        );
        
        add_submenu_page(
            'ai-questionnaire',
            'پاسخ‌ها و تحلیل‌ها',
            'پاسخ‌ها',
            'manage_options',
            'ai-questionnaire-answers',
            array($this, 'admin_answers_page')
        );
        
        add_submenu_page(
            'ai-questionnaire',
            'تنظیمات',
            'تنظیمات',
            'manage_options',
            'ai-questionnaire-settings',
            array($this, 'admin_settings_page')
        );
    }
    
    // بارگذاری اسکریپت‌های ادمین
    public function admin_enqueue_scripts($hook) {
        if (strpos($hook, 'ai-questionnaire') === false) {
            return;
        }
        
        wp_enqueue_style('aiq-admin-style', AIQ_PLUGIN_URL . 'admin-style.css', array(), AIQ_VERSION);
    }
    
    // صفحه تنظیمات
    public function admin_settings_page() {
        $webhook_url = get_option('aiq_n8n_webhook_url', '');
        ?>
        <div class="wrap">
            <h1>تنظیمات پرسشنامه AI</h1>
            
            <form method="post" id="aiq-settings-form">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="webhook_url">آدرس Webhook سرویس n8n</label>
                        </th>
                        <td>
                            <input type="url" 
                                   id="webhook_url" 
                                   name="webhook_url" 
                                   value="<?php echo esc_attr($webhook_url); ?>" 
                                   class="regular-text"
                                   placeholder="https://your-n8n-instance.com/webhook/...">
                            <p class="description">
                                آدرس کامل webhook که در n8n ساخته‌اید را وارد کنید
                            </p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary">ذخیره تنظیمات</button>
                </p>
            </form>
        </div>
        
        <style>
            .wrap { font-family: Tahoma, Arial; direction: rtl; text-align: right; }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            $('#aiq-settings-form').on('submit', function(e) {
                e.preventDefault();
                
                $.post(ajaxurl, {
                    action: 'aiq_update_settings',
                    webhook_url: $('#webhook_url').val(),
                    _wpnonce: '<?php echo wp_create_nonce('aiq_settings'); ?>'
                }, function(response) {
                    if (response.success) {
                        alert('تنظیمات با موفقیت ذخیره شد');
                    } else {
                        alert('خطا در ذخیره تنظیمات');
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    // به‌روزرسانی تنظیمات
    public function update_settings() {
        check_ajax_referer('aiq_settings');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('دسترسی غیرمجاز');
        }
        
        $webhook_url = esc_url_raw($_POST['webhook_url']);
        update_option('aiq_n8n_webhook_url', $webhook_url);
        
        wp_send_json_success();
    }
    
    // صفحه مدیریت سوالات
    public function admin_questions_page() {
        global $wpdb;
        $questions = $wpdb->get_results("SELECT * FROM {$this->table_questions} ORDER BY question_order ASC");
        ?>
        <div class="wrap aiq-admin-wrap">
            <h1>مدیریت سوالات پرسشنامه</h1>
            
            <div class="aiq-add-question-box">
                <h2>افزودن سوال جدید</h2>
                <form id="aiq-add-question-form">
                    <?php wp_nonce_field('aiq_save_question', 'aiq_nonce'); ?>
                    <textarea id="question_text" 
                              name="question_text" 
                              rows="3" 
                              placeholder="متن سوال را وارد کنید..."
                              required></textarea>
                    <br><br>
                    <button type="submit" class="button button-primary">افزودن سوال</button>
                </form>
            </div>
            
            <h2>لیست سوالات</h2>
            <?php if (empty($questions)): ?>
                <p>هنوز سوالی اضافه نشده است.</p>
            <?php else: ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width: 80px;">ترتیب</th>
                        <th>متن سوال</th>
                        <th style="width: 180px;">تاریخ ایجاد</th>
                        <th style="width: 120px;">عملیات</th>
                    </tr>
                </thead>
                <tbody id="questions-list">
                    <?php foreach($questions as $q): ?>
                    <tr data-id="<?php echo $q->id; ?>">
                        <td><?php echo $q->question_order; ?></td>
                        <td><?php echo esc_html($q->question_text); ?></td>
                        <td><?php echo esc_html($q->created_at); ?></td>
                        <td>
                            <button class="button button-small aiq-delete-question" 
                                    data-id="<?php echo $q->id; ?>">
                                حذف
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
        
        <style>
            .aiq-admin-wrap { font-family: Tahoma, Arial; direction: rtl; text-align: right; }
            .aiq-add-question-box { background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ccc; border-radius: 5px; }
            .aiq-add-question-box textarea { width: 100%; padding: 10px; font-family: Tahoma, Arial; }
            .wp-list-table { direction: rtl; }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            // افزودن سوال
            $('#aiq-add-question-form').on('submit', function(e) {
                e.preventDefault();
                var questionText = $('#question_text').val().trim();
                
                if (!questionText) {
                    alert('لطفا متن سوال را وارد کنید');
                    return;
                }
                
                $.post(ajaxurl, {
                    action: 'aiq_save_question',
                    question_text: questionText,
                    _wpnonce: $('[name="aiq_nonce"]').val()
                }, function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert('خطا در ذخیره سوال: ' + (response.data || ''));
                    }
                });
            });
            
            // حذف سوال
            $('.aiq-delete-question').on('click', function() {
                if (!confirm('آیا از حذف این سوال مطمئن هستید؟')) {
                    return;
                }
                
                var id = $(this).data('id');
                var $row = $(this).closest('tr');
                
                $.post(ajaxurl, {
                    action: 'aiq_delete_question',
                    question_id: id,
                    _wpnonce: '<?php echo wp_create_nonce('aiq_delete_question'); ?>'
                }, function(response) {
                    if (response.success) {
                        $row.fadeOut(300, function() { $(this).remove(); });
                    } else {
                        alert('خطا در حذف سوال');
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    // صفحه پاسخ‌ها و تحلیل‌ها
    public function admin_answers_page() {
        global $wpdb;
        
        $users_with_answers = $wpdb->get_results("
            SELECT DISTINCT u.ID, u.display_name, u.user_email, 
                   MAX(a.submitted_at) as last_submission
            FROM {$wpdb->users} u
            INNER JOIN {$this->table_answers} a ON u.ID = a.user_id
            GROUP BY u.ID
            ORDER BY last_submission DESC
        ");
        ?>
        <div class="wrap aiq-admin-wrap">
            <h1>پاسخ‌ها و تحلیل‌های کاربران</h1>
            
            <?php if (empty($users_with_answers)): ?>
                <p>هنوز هیچ کاربری پاسخی ثبت نکرده است.</p>
            <?php else: ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>نام کاربر</th>
                        <th>ایمیل</th>
                        <th>آخرین پاسخ</th>
                        <th style="width: 180px;">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($users_with_answers as $user): ?>
                    <tr>
                        <td><?php echo esc_html($user->display_name); ?></td>
                        <td><?php echo esc_html($user->user_email); ?></td>
                        <td><?php echo esc_html($user->last_submission); ?></td>
                        <td>
                            <button class="button aiq-view-analysis" 
                                    data-user-id="<?php echo $user->ID; ?>">
                                مشاهده تحلیل
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
            
            <!-- Modal -->
            <div id="aiq-analysis-modal" class="aiq-modal">
                <div class="aiq-modal-content">
                    <span class="aiq-modal-close">&times;</span>
                    <h2>تحلیل و پاسخ‌های کاربر</h2>
                    <div id="aiq-analysis-content"></div>
                </div>
            </div>
        </div>
        
        <style>
            .aiq-modal { 
                display: none; 
                position: fixed; 
                z-index: 9999; 
                left: 0; 
                top: 0; 
                width: 100%; 
                height: 100%; 
                background-color: rgba(0,0,0,0.6); 
            }
            .aiq-modal-content { 
                background-color: #fefefe; 
                margin: 5% auto; 
                padding: 30px; 
                border: 1px solid #888; 
                width: 80%; 
                max-width: 900px; 
                max-height: 80vh; 
                overflow-y: auto;
                border-radius: 8px;
                direction: rtl;
                text-align: right;
                font-family: Tahoma, Arial;
            }
            .aiq-modal-close { 
                color: #aaa; 
                float: left; 
                font-size: 28px; 
                font-weight: bold; 
                cursor: pointer; 
            }
            .aiq-modal-close:hover { color: #000; }
            .aiq-qa-item { 
                margin-bottom: 25px; 
                padding: 15px; 
                background: #f9f9f9; 
                border-right: 4px solid #0073aa; 
                border-radius: 4px;
            }
            .aiq-qa-item strong { color: #0073aa; }
            .aiq-analysis-box { 
                margin-top: 30px; 
                padding: 20px; 
                background: #e8f5e9; 
                border-radius: 5px; 
                border: 2px solid #4caf50;
            }
            .aiq-analysis-box h3 { color: #2e7d32; margin-top: 0; }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            var modal = $('#aiq-analysis-modal');
            
            $('.aiq-view-analysis').on('click', function() {
                var userId = $(this).data('user-id');
                
                $('#aiq-analysis-content').html('<p>در حال بارگذاری...</p>');
                modal.show();
                
                $.post(ajaxurl, {
                    action: 'aiq_get_user_analysis',
                    user_id: userId,
                    _wpnonce: '<?php echo wp_create_nonce('aiq_get_analysis'); ?>'
                }, function(response) {
                    if (response.success) {
                        $('#aiq-analysis-content').html(response.data.html);
                    } else {
                        $('#aiq-analysis-content').html('<p>خطا در بارگذاری اطلاعات</p>');
                    }
                });
            });
            
            $('.aiq-modal-close').on('click', function() {
                modal.hide();
            });
            
            $(window).on('click', function(e) {
                if ($(e.target).is('#aiq-analysis-modal')) {
                    modal.hide();
                }
            });
        });
        </script>
        <?php
    }
    
    // شورت‌کد فرم کاربر
    public function questionnaire_shortcode() {
        if (!is_user_logged_in()) {
            return '<div class="aiq-message">برای پاسخ به پرسشنامه باید وارد شوید.</div>';
        }
        
        global $wpdb;
        $user_id = get_current_user_id();
        
        // بررسی اینکه کاربر قبلا پاسخ داده یا نه
        $has_answered = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_answers} WHERE user_id = %d",
            $user_id
        ));
        
        if ($has_answered > 0) {
            $analysis = $wpdb->get_var($wpdb->prepare(
                "SELECT analysis_text FROM {$this->table_analysis} 
                 WHERE user_id = %d ORDER BY created_at DESC LIMIT 1",
                $user_id
            ));
            
            ob_start();
            ?>
            <div class="aiq-questionnaire-completed">
                <h3>✅ شما قبلا به این پرسشنامه پاسخ داده‌اید</h3>
                
                <?php if ($analysis): ?>
                <div class="aiq-user-analysis">
                    <h4>تحلیل هوش مصنوعی:</h4>
                    <div class="aiq-analysis-text">
                        <?php echo nl2br(esc_html($analysis)); ?>
                    </div>
                </div>
                <?php else: ?>
                <p>تحلیل شما در حال پردازش است...</p>
                <?php endif; ?>
            </div>
            <?php
            return ob_get_clean();
        }
        
        $questions = $wpdb->get_results("SELECT * FROM {$this->table_questions} ORDER BY question_order ASC");
        
        if (empty($questions)) {
            return '<div class="aiq-message">هنوز سوالی برای این پرسشنامه تعریف نشده است.</div>';
        }
        
        ob_start();
        ?>
        <div class="aiq-questionnaire-form">
            <h2>پرسشنامه</h2>
            <p>لطفا به سوالات زیر با دقت پاسخ دهید:</p>
            
            <form id="aiq-questionnaire-form">
                <?php wp_nonce_field('aiq_submit_answers', 'aiq_nonce'); ?>
                
                <?php foreach($questions as $index => $q): ?>
                <div class="aiq-question-block">
                    <label class="aiq-question-label">
                        <span class="aiq-question-number"><?php echo ($index + 1); ?>.</span>
                        <?php echo esc_html($q->question_text); ?>
                    </label>
                    <textarea 
                        name="answer[<?php echo $q->id; ?>]" 
                        rows="4" 
                        placeholder="پاسخ خود را اینجا بنویسید..."
                        required
                    ></textarea>
                </div>
                <?php endforeach; ?>
                
                <div class="aiq-submit-wrapper">
                    <button type="submit" class="aiq-submit-btn" id="aiq-submit-btn">
                        ارسال پاسخ‌ها
                    </button>
                </div>
                
                <div id="aiq-loading-message" style="display: none;">
                    <div class="aiq-loader"></div>
                    <p>در حال پردازش و تحلیل پاسخ‌های شما توسط هوش مصنوعی... لطفا صبر کنید.</p>
                </div>
            </form>
            
            <div id="aiq-analysis-result" style="display: none;">
                <h3>✅ پاسخ‌های شما با موفقیت ثبت شد</h3>
                <div class="aiq-analysis-box">
                    <h4>تحلیل هوش مصنوعی:</h4>
                    <div id="aiq-analysis-text"></div>
                </div>
            </div>
        </div>
        
        <style>
            .aiq-questionnaire-form,
            .aiq-questionnaire-completed {
                font-family: Tahoma, Arial, sans-serif;
                direction: rtl;
                text-align: right;
                max-width: 800px;
                margin: 20px auto;
                padding: 30px;
                background: #fff;
                border-radius: 8px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            .aiq-message {
                padding: 20px;
                background: #fff3cd;
                border: 1px solid #ffc107;
                border-radius: 5px;
                text-align: center;
            }
            .aiq-question-block {
                margin-bottom: 30px;
                padding: 20px;
                background: #f9f9f9;
                border-radius: 6px;
                border-right: 4px solid #0073aa;
            }
            .aiq-question-label {
                display: block;
                font-weight: bold;
                margin-bottom: 10px;
                color: #333;
                font-size: 16px;
            }
            .aiq-question-number {
                display: inline-block;
                background: #0073aa;
                color: white;
                width: 30px;
                height: 30px;
                line-height: 30px;
                text-align: center;
                border-radius: 50%;
                margin-left: 10px;
            }
            .aiq-question-block textarea {
                width: 100%;
                padding: 12px;
                border: 2px solid #ddd;
                border-radius: 5px;
                font-family: Tahoma, Arial;
                font-size: 14px;
                resize: vertical;
                transition: border-color 0.3s;
            }
            .aiq-question-block textarea:focus {
                outline: none;
                border-color: #0073aa;
            }
            .aiq-submit-wrapper {
                text-align: center;
                margin-top: 30px;
            }
            .aiq-submit-btn {
                background: #0073aa;
                color: white;
                border: none;
                padding: 15px 40px;
                font-size: 16px;
                font-weight: bold;
                border-radius: 5px;
                cursor: pointer;
                transition: background 0.3s;
            }
            .aiq-submit-btn:hover {
                background: #005a87;
            }
            .aiq-submit-btn:disabled {
                background: #ccc;
                cursor: not-allowed;
            }
            #aiq-loading-message {
                text-align: center;
                padding: 30px;
                background: #e3f2fd;
                border-radius: 5px;
                margin-top: 20px;
            }
            .aiq-loader {
                border: 4px solid #f3f3f3;
                border-top: 4px solid #0073aa;
                border-radius: 50%;
                width: 40px;
                height: 40px;
                animation: spin 1s linear infinite;
                margin: 0 auto 15px;
            }
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            .aiq-analysis-box {
                background: #e8f5e9;
                padding: 20px;
                border-radius: 5px;
                border: 2px solid #4caf50;
                margin-top: 20px;
            }
            .aiq-analysis-box h4 {
                color: #2e7d32;
                margin-top: 0;
            }
            #aiq-analysis-text {
                line-height: 1.8;
                color: #333;
            }
            .aiq-user-analysis {
                margin-top: 20px;
            }
            .aiq-analysis-text {
                background: #f5f5f5;
                padding: 20px;
                border-radius: 5px;
                line-height: 1.8;
            }
        </style>
        <?php
        return ob_get_clean();
    }
    
    // ذخیره سوال جدید
    public function save_question() {
        check_ajax_referer('aiq_save_question', 'aiq_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('دسترسی غیرمجاز');
        }
        
        global $wpdb;
        
        $question_text = sanitize_textarea_field($_POST['question_text']);
        
        if (empty($question_text)) {
            wp_send_json_error('متن سوال خالی است');
        }
        
        $max_order = $wpdb->get_var("SELECT MAX(question_order) FROM {$this->table_questions}");
        
        $result = $wpdb->insert(
            $this->table_questions,
            array(
                'question_text' => $question_text,
                'question_order' => intval($max_order) + 1
            ),
            array('%s', '%d')
        );
        
        if ($result) {
            wp_send_json_success();
        } else {
            wp_send_json_error('خطا در ذخیره سوال');
        }
    }
    
    // حذف سوال
    public function delete_question() {
        check_ajax_referer('aiq_delete_question');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('دسترسی غیرمجاز');
        }
        
        global $wpdb;
        $question_id = intval($_POST['question_id']);
        
        $result = $wpdb->delete(
            $this->table_questions, 
            array('id' => $question_id),
            array('%d')
        );
        
        if ($result) {
            wp_send_json_success();
        } else {
            wp_send_json_error('خطا در حذف سوال');
        }
    }
    
    // ذخیره پاسخ‌ها و ارسال به n8n
    public function handle_submit_answers() {
        check_ajax_referer('aiq_submit_answers', 'aiq_nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error('لطفا وارد شوید');
        }
        
        global $wpdb;
        $user_id = get_current_user_id();
        $answers = isset($_POST['answers']) ? $_POST['answers'] : array();
        
        if (empty($answers)) {
            wp_send_json_error('پاسخی ارسال نشده است');
        }
        
        // بررسی اینکه کاربر قبلا پاسخ داده یا نه
        $has_answered = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_answers} WHERE user_id = %d",
            $user_id
        ));
        
        if ($has_answered > 0) {
            wp_send_json_error('شما قبلا به این پرسشنامه پاسخ داده‌اید');
        }
        
        // ذخیره پاسخ‌ها و آماده‌سازی داده برای n8n
        $qa_pairs = array();
        
        foreach ($answers as $question_id => $answer) {
            $question_id = intval($question_id);
            $answer = sanitize_textarea_field($answer);
            
            if (empty($answer)) {
                continue;
            }
            
            // ذخیره در دیتابیس
            $wpdb->insert(
                $this->table_answers,
                array(
                    'user_id' => $user_id,
                    'question_id' => $question_id,
                    'answer_text' => $answer
                ),
                array('%d', '%d', '%s')
            );
            
            // دریافت متن سوال
            $question_text = $wpdb->get_var($wpdb->prepare(
                "SELECT question_text FROM {$this->table_questions} WHERE id = %d",
                $question_id
            ));
            
            if ($question_text) {
                $qa_pairs[] = array(
                    'question' => $question_text,
                    'answer' => $answer
                );
            }
        }
        
        // ارسال به n8n
        $webhook_url = get_option('aiq_n8n_webhook_url');
        
        if (empty($webhook_url)) {
            wp_send_json_error('آدرس webhook تنظیم نشده است. لطفا با مدیر سایت تماس بگیرید.');
        }
        
        $user_info = wp_get_current_user();
        
        $payload = array(
            'user_id' => $user_id,
            'user_name' => $user_info->display_name,
            'user_email' => $user_info->user_email,
            'qa_pairs' => $qa_pairs,
            'submitted_at' => current_time('mysql'),
            'site_url' => get_site_url()
        );
        
        // ارسال درخواست به n8n
        $response = wp_remote_post($webhook_url, array(
            'method' => 'POST',
            'timeout' => 45,
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode($payload),
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error('خطا در ارسال به سیستم تحلیل: ' . $response->get_error_message());
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($response_code !== 200) {
            wp_send_json_error('خطا در دریافت پاسخ از سیستم تحلیل');
        }
        
        $data = json_decode($body, true);
        
        // ذخیره تحلیل در دیتابیس
        if (isset($data['analysis']) && !empty($data['analysis'])) {
            $wpdb->insert(
                $this->table_analysis,
                array(
                    'user_id' => $user_id,
                    'analysis_text' => $data['analysis']
                ),
                array('%d', '%s')
            );
            
            wp_send_json_success(array(
                'message' => 'پاسخ‌های شما با موفقیت ثبت و تحلیل شد',
                'analysis' => $data['analysis']
            ));
        } else {
            wp_send_json_error('تحلیل دریافت نشد. لطفا بعدا مراجعه کنید.');
        }
    }
    
    // دریافت تحلیل کاربر برای ادمین
    public function get_user_analysis() {
        check_ajax_referer('aiq_get_analysis');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('دسترسی غیرمجاز');
        }
        
        global $wpdb;
        $user_id = intval($_POST['user_id']);
        
        // دریافت اطلاعات کاربر
        $user_info = get_userdata($user_id);
        
        // دریافت سوالات و پاسخ‌ها
        $qa_data = $wpdb->get_results($wpdb->prepare("
            SELECT q.question_text, a.answer_text, a.submitted_at
            FROM {$this->table_answers} a
            JOIN {$this->table_questions} q ON a.question_id = q.id
            WHERE a.user_id = %d
            ORDER BY q.question_order ASC
        ", $user_id));
        
        // دریافت تحلیل
        $analysis = $wpdb->get_var($wpdb->prepare(
            "SELECT analysis_text FROM {$this->table_analysis} 
             WHERE user_id = %d 
             ORDER BY created_at DESC 
             LIMIT 1",
            $user_id
        ));
        
        // ساخت HTML
        $html = '<div class="aiq-user-info">';
        $html .= '<h3>اطلاعات کاربر</h3>';
        $html .= '<p><strong>نام:</strong> ' . esc_html($user_info->display_name) . '</p>';
        $html .= '<p><strong>ایمیل:</strong> ' . esc_html($user_info->user_email) . '</p>';
        $html .= '</div>';
        
        $html .= '<hr>';
        
        $html .= '<div class="aiq-qa-section">';
        $html .= '<h3>سوالات و پاسخ‌ها</h3>';
        
        foreach ($qa_data as $index => $item) {
            $html .= '<div class="aiq-qa-item">';
            $html .= '<p><strong>سوال ' . ($index + 1) . ':</strong> ' . esc_html($item->question_text) . '</p>';
            $html .= '<p><strong>پاسخ:</strong> ' . nl2br(esc_html($item->answer_text)) . '</p>';
            $html .= '</div>';
        }
        
        $html .= '</div>';
        
        if ($analysis) {
            $html .= '<div class="aiq-analysis-box">';
            $html .= '<h3>🤖 تحلیل هوش مصنوعی</h3>';
            $html .= '<div>' . nl2br(esc_html($analysis)) . '</div>';
            $html .= '</div>';
        } else {
            $html .= '<div class="aiq-no-analysis">';
            $html .= '<p>تحلیل هوش مصنوعی هنوز دریافت نشده است.</p>';
            $html .= '</div>';
        }
        
        wp_send_json_success(array('html' => $html));
    }
    
    // بارگذاری اسکریپت‌های فرانت‌اند
    public function enqueue_scripts() {
        if (!has_shortcode(get_post()->post_content, 'ai_questionnaire')) {
            return;
        }
        
        wp_enqueue_script('jquery');
        
        // اضافه کردن کد JavaScript برای فرم
        wp_add_inline_script('jquery', "
            jQuery(document).ready(function($) {
                $('#aiq-questionnaire-form').on('submit', function(e) {
                    e.preventDefault();
                    
                    // غیرفعال کردن دکمه
                    $('#aiq-submit-btn').prop('disabled', true).text('در حال ارسال...');
                    $('#aiq-loading-message').show();
                    
                    // جمع‌آوری داده‌ها
                    var formData = $(this).serializeArray();
                    var answers = {};
                    
                    formData.forEach(function(field) {
                        var match = field.name.match(/answer\[(\d+)\]/);
                        if (match) {
                            answers[match[1]] = field.value;
                        }
                    });
                    
                    // ارسال AJAX
                    $.ajax({
                        url: '" . admin_url('admin-ajax.php') . "',
                        type: 'POST',
                        data: {
                            action: 'aiq_submit_answers',
                            answers: answers,
                            aiq_nonce: $('[name=\"aiq_nonce\"]').val()
                        },
                        timeout: 60000, // 60 ثانیه تایم‌اوت
                        success: function(response) {
                            $('#aiq-loading-message').hide();
                            
                            if (response.success) {
                                $('#aiq-questionnaire-form').hide();
                                $('#aiq-analysis-result').show();
                                $('#aiq-analysis-text').html(response.data.analysis.replace(/\\n/g, '<br>'));
                                
                                // اسکرول به نتیجه
                                $('html, body').animate({
                                    scrollTop: $('#aiq-analysis-result').offset().top - 100
                                }, 500);
                            } else {
                                alert('خطا: ' + (response.data || 'خطای نامشخص'));
                                $('#aiq-submit-btn').prop('disabled', false).text('ارسال پاسخ‌ها');
                            }
                        },
                        error: function(xhr, status, error) {
                            $('#aiq-loading-message').hide();
                            $('#aiq-submit-btn').prop('disabled', false).text('ارسال پاسخ‌ها');
                            
                            if (status === 'timeout') {
                                alert('زمان پردازش به اتمام رسید. لطفا دوباره تلاش کنید.');
                            } else {
                                alert('خطا در ارتباط با سرور. لطفا دوباره تلاش کنید.');
                            }
                        }
                    });
                });
            });
        ");
    }
}

// راه‌اندازی افزونه
function aiq_init() {
    new AI_Questionnaire_System();
}
add_action('plugins_loaded', 'aiq_init');

// هوک برای غیرفعال‌سازی افزونه (اختیاری)
register_deactivation_hook(__FILE__, 'aiq_deactivation');
function aiq_deactivation() {
    // در صورت نیاز می‌توانید کدهای پاکسازی اضافه کنید
}